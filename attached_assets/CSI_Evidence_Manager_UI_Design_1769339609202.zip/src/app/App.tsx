import { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { DashboardScreen } from './components/DashboardScreen';
import { CreateInvestigationScreen } from './components/CreateInvestigationScreen';
import { ActiveInvestigationScreen } from './components/ActiveInvestigationScreen';
import { TimelineScreen } from './components/TimelineScreen';
import { EvidenceGalleryScreen } from './components/EvidenceGalleryScreen';
import { AIAnalysisScreen } from './components/AIAnalysisScreen';
import { ChainOfCustodyScreen } from './components/ChainOfCustodyScreen';
import { ReportsScreen } from './components/ReportsScreen';
import type { Case } from './components/CaseCard';
import type { Evidence } from './components/EvidenceCard';

type Screen =
  | 'login'
  | 'dashboard'
  | 'create-investigation'
  | 'active-investigation'
  | 'timeline'
  | 'evidence-gallery'
  | 'ai-analysis'
  | 'chain-of-custody'
  | 'reports';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [officerName, setOfficerName] = useState('');
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string | null>(null);

  // Mock data
  const [cases, setCases] = useState<Case[]>([
    {
      id: '1',
      title: 'Vehicle Theft Investigation',
      caseNumber: 'CS-2026-0125-001',
      date: 'Jan 25, 2026',
      status: 'active'
    },
    {
      id: '2',
      title: 'Commercial Burglary - Main Street',
      caseNumber: 'CS-2026-0124-003',
      date: 'Jan 24, 2026',
      status: 'active'
    },
    {
      id: '3',
      title: 'Traffic Accident Scene Documentation',
      caseNumber: 'CS-2026-0123-007',
      date: 'Jan 23, 2026',
      status: 'closed'
    }
  ]);

  const mockEvidence: Evidence[] = [
    {
      id: 'ev1',
      type: 'photo',
      timestamp: '14:23:47',
      caseId: '1',
      evidenceId: 'EV-2026-0125-001'
    },
    {
      id: 'ev2',
      type: 'photo',
      timestamp: '14:24:12',
      caseId: '1',
      evidenceId: 'EV-2026-0125-002'
    },
    {
      id: 'ev3',
      type: 'video',
      timestamp: '14:25:03',
      caseId: '1',
      evidenceId: 'EV-2026-0125-003'
    },
    {
      id: 'ev4',
      type: 'photo',
      timestamp: '14:28:45',
      caseId: '1',
      evidenceId: 'EV-2026-0125-004'
    }
  ];

  const mockTimelineEvents = [
    {
      id: 'te1',
      type: 'video_start' as const,
      timestamp: '14:20:00',
      description: 'Recording session initiated',
      metadata: {
        'Officer': 'Det. J. Martinez',
        'Location': '1234 Main St'
      }
    },
    {
      id: 'te2',
      type: 'photo' as const,
      timestamp: '14:23:47',
      description: 'Evidence photo captured - Vehicle license plate',
      metadata: {
        'Evidence ID': 'EV-2026-0125-001',
        'GPS': '37.7749, -122.4194'
      }
    },
    {
      id: 'te3',
      type: 'photo' as const,
      timestamp: '14:24:12',
      description: 'Evidence photo captured - Driver side window damage',
      metadata: {
        'Evidence ID': 'EV-2026-0125-002',
        'GPS': '37.7749, -122.4194'
      }
    },
    {
      id: 'te4',
      type: 'marker' as const,
      timestamp: '14:26:30',
      description: 'Manual marker - Witness statement location',
      metadata: {
        'Notes': 'Indicated by witness',
        'GPS': '37.7750, -122.4195'
      }
    }
  ];

  const mockCustodyRecords = [
    {
      evidenceId: 'EV-2026-0125-001',
      type: 'photo' as const,
      capturedBy: 'Det. J. Martinez #4521',
      timestamp: '2026-01-25 14:23:47',
      location: '37.7749° N, 122.4194° W',
      hash: 'SHA256:a3f5c8d9e2b1f4a6c7e8d9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0',
      status: 'verified' as const
    },
    {
      evidenceId: 'EV-2026-0125-002',
      type: 'photo' as const,
      capturedBy: 'Det. J. Martinez #4521',
      timestamp: '2026-01-25 14:24:12',
      location: '37.7749° N, 122.4194° W',
      hash: 'SHA256:b4a6d9e3c2f5a7b8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1',
      status: 'verified' as const
    },
    {
      evidenceId: 'EV-2026-0125-003',
      type: 'video' as const,
      capturedBy: 'Det. J. Martinez #4521',
      timestamp: '2026-01-25 14:25:03',
      location: '37.7749° N, 122.4194° W',
      hash: 'SHA256:c5b7e0f4d3a6b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2',
      status: 'verified' as const
    }
  ];

  const handleLogin = (email: string, password: string) => {
    setOfficerName('Det. J. Martinez');
    setIsAuthenticated(true);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setOfficerName('');
    setCurrentScreen('login');
    setSelectedCaseId(null);
  };

  const handleCreateCase = () => {
    setCurrentScreen('create-investigation');
  };

  const handleStartInvestigation = (data: { title: string; caseNumber: string; location: string }) => {
    const newCase: Case = {
      id: String(cases.length + 1),
      title: data.title,
      caseNumber: data.caseNumber,
      date: new Date().toLocaleDateString('en-US', { dateStyle: 'medium' }),
      status: 'active'
    };
    setCases([...cases, newCase]);
    setSelectedCaseId(newCase.id);
    setCurrentScreen('active-investigation');
  };

  const handleSelectCase = (caseId: string) => {
    setSelectedCaseId(caseId);
    setCurrentScreen('active-investigation');
  };

  const selectedCase = cases.find((c) => c.id === selectedCaseId);

  const renderScreen = () => {
    if (!isAuthenticated && currentScreen !== 'login') {
      return <LoginScreen onLogin={handleLogin} />;
    }

    switch (currentScreen) {
      case 'login':
        return <LoginScreen onLogin={handleLogin} />;

      case 'dashboard':
        return (
          <DashboardScreen
            officerName={officerName}
            badgeId="#4521"
            cases={cases}
            onCreateCase={handleCreateCase}
            onSelectCase={handleSelectCase}
            onLogout={handleLogout}
          />
        );

      case 'create-investigation':
        return (
          <CreateInvestigationScreen
            officerName={officerName}
            onBack={() => setCurrentScreen('dashboard')}
            onStart={handleStartInvestigation}
          />
        );

      case 'active-investigation':
        return selectedCase ? (
          <ActiveInvestigationScreen
            caseNumber={selectedCase.caseNumber}
            caseTitle={selectedCase.title}
            onBack={() => setCurrentScreen('dashboard')}
            onViewTimeline={() => setCurrentScreen('timeline')}
            onViewEvidence={() => setCurrentScreen('evidence-gallery')}
          />
        ) : (
          <div>Case not found</div>
        );

      case 'timeline':
        return selectedCase ? (
          <TimelineScreen
            caseNumber={selectedCase.caseNumber}
            caseTitle={selectedCase.title}
            events={mockTimelineEvents}
            onBack={() => setCurrentScreen('active-investigation')}
            onSelectEvent={(eventId) => console.log('Selected event:', eventId)}
          />
        ) : (
          <div>Case not found</div>
        );

      case 'evidence-gallery':
        return selectedCase ? (
          <EvidenceGalleryScreen
            caseNumber={selectedCase.caseNumber}
            caseTitle={selectedCase.title}
            evidence={mockEvidence}
            onBack={() => setCurrentScreen('active-investigation')}
            onSelectEvidence={(evidenceId) => {
              setSelectedEvidenceId(evidenceId);
              setCurrentScreen('ai-analysis');
            }}
            onAnalyze={(evidenceId) => {
              setSelectedEvidenceId(evidenceId);
              setCurrentScreen('ai-analysis');
            }}
          />
        ) : (
          <div>Case not found</div>
        );

      case 'ai-analysis':
        return selectedCase && selectedEvidenceId ? (
          <AIAnalysisScreen
            evidenceId={selectedEvidenceId}
            caseNumber={selectedCase.caseNumber}
            onBack={() => setCurrentScreen('evidence-gallery')}
            onApprove={(description) => {
              console.log('Approved:', description);
              setCurrentScreen('evidence-gallery');
            }}
          />
        ) : (
          <div>Evidence not found</div>
        );

      case 'chain-of-custody':
        return selectedCase ? (
          <ChainOfCustodyScreen
            caseNumber={selectedCase.caseNumber}
            caseTitle={selectedCase.title}
            records={mockCustodyRecords}
            onBack={() => setCurrentScreen('dashboard')}
            onGenerateReport={() => console.log('Generating report...')}
          />
        ) : (
          <div>Case not found</div>
        );

      case 'reports':
        return selectedCase ? (
          <ReportsScreen
            caseNumber={selectedCase.caseNumber}
            caseTitle={selectedCase.title}
            evidenceCount={mockEvidence.length}
            timelineEvents={mockTimelineEvents.length}
            onBack={() => setCurrentScreen('dashboard')}
          />
        ) : (
          <div>Case not found</div>
        );

      default:
        return <LoginScreen onLogin={handleLogin} />;
    }
  };

  return (
    <div className="dark min-h-screen">
      {renderScreen()}
    </div>
  );
}
