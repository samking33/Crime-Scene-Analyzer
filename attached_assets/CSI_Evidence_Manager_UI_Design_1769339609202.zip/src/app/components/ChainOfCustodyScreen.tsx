import React from 'react';
import { ArrowLeft, Download, Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import { StatusBadge } from './StatusBadge';

interface CustodyRecord {
  evidenceId: string;
  type: 'photo' | 'video';
  capturedBy: string;
  timestamp: string;
  location: string;
  hash: string;
  status: 'verified' | 'modified' | 'exported';
}

interface ChainOfCustodyScreenProps {
  caseNumber: string;
  caseTitle: string;
  records: CustodyRecord[];
  onBack: () => void;
  onGenerateReport: () => void;
}

export function ChainOfCustodyScreen({
  caseNumber,
  caseTitle,
  records,
  onBack,
  onGenerateReport
}: ChainOfCustodyScreenProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                <h1 className="font-semibold text-foreground">Chain of Custody</h1>
              </div>
              <p className="text-xs font-mono text-muted-foreground">{caseNumber}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container max-w-2xl mx-auto px-4 py-6">
        <div className="mb-6">
          <button
            onClick={onGenerateReport}
            className="w-full bg-primary text-primary-foreground px-6 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
          >
            <Download className="w-5 h-5" />
            Generate Custody Report (PDF)
          </button>
        </div>

        <div className="mb-4">
          <h2 className="font-semibold text-foreground">Audit Trail</h2>
          <p className="text-sm text-muted-foreground">{records.length} evidence items logged</p>
        </div>

        <div className="space-y-3">
          {records.map((record) => (
            <div
              key={record.evidenceId}
              className="bg-card border border-border rounded-lg p-4"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="font-mono text-sm text-foreground font-semibold mb-1">
                    {record.evidenceId}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {record.type.toUpperCase()}
                  </div>
                </div>
                {record.status === 'verified' ? (
                  <StatusBadge variant="active" size="sm">
                    <CheckCircle className="w-3 h-3" />
                    <span className="ml-1">VERIFIED</span>
                  </StatusBadge>
                ) : record.status === 'modified' ? (
                  <StatusBadge variant="warning" size="sm">
                    <AlertTriangle className="w-3 h-3" />
                    <span className="ml-1">MODIFIED</span>
                  </StatusBadge>
                ) : (
                  <StatusBadge variant="evidence" size="sm">
                    EXPORTED
                  </StatusBadge>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-muted-foreground">Captured By:</span>
                  <div className="text-foreground font-medium mt-0.5">{record.capturedBy}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Timestamp:</span>
                  <div className="text-foreground font-medium font-mono mt-0.5">{record.timestamp}</div>
                </div>
                <div className="col-span-2">
                  <span className="text-muted-foreground">Location:</span>
                  <div className="text-foreground font-medium mt-0.5">{record.location}</div>
                </div>
                <div className="col-span-2">
                  <span className="text-muted-foreground">Integrity Hash:</span>
                  <div className="text-foreground font-mono text-xs mt-0.5 break-all">
                    {record.hash}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {records.length === 0 && (
          <div className="bg-card border border-border rounded-lg p-8 text-center">
            <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No custody records</p>
            <p className="text-sm text-muted-foreground mt-1">
              Evidence items will appear here once captured
            </p>
          </div>
        )}

        <div className="mt-6 bg-card border border-border rounded-lg p-4">
          <p className="text-xs text-muted-foreground leading-relaxed">
            This chain of custody log maintains cryptographic integrity verification for all evidence.
            Any modification to evidence files will invalidate the hash and trigger a modified status.
            This audit trail is admissible in legal proceedings.
          </p>
        </div>
      </div>
    </div>
  );
}