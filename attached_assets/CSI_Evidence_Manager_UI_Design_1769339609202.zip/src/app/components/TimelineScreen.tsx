import React from 'react';
import { ArrowLeft, Play, Camera, MapPin, Hash } from 'lucide-react';
import { StatusBadge } from './StatusBadge';

interface TimelineEvent {
  id: string;
  type: 'video_start' | 'photo' | 'marker';
  timestamp: string;
  description: string;
  thumbnail?: string;
  metadata?: Record<string, string>;
}

interface TimelineScreenProps {
  caseNumber: string;
  caseTitle: string;
  events: TimelineEvent[];
  onBack: () => void;
  onSelectEvent: (eventId: string) => void;
}

export function TimelineScreen({
  caseNumber,
  caseTitle,
  events,
  onBack,
  onSelectEvent
}: TimelineScreenProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-2">
            <button
              onClick={onBack}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <h1 className="font-semibold text-foreground">Timeline Viewer</h1>
              <p className="text-xs font-mono text-muted-foreground">{caseNumber}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Video Player */}
      <div className="bg-black aspect-video relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <Play className="w-16 h-16 text-gray-600" />
        </div>
        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-black/70 rounded-lg p-2">
            <div className="h-1 bg-gray-700 rounded-full">
              <div className="h-full w-1/3 bg-primary rounded-full" />
            </div>
            <div className="flex items-center justify-between mt-2 text-xs text-white font-mono">
              <span>00:12:34</span>
              <span>00:38:22</span>
            </div>
          </div>
        </div>
      </div>

      {/* Timeline Events */}
      <div className="container max-w-2xl mx-auto px-4 py-6">
        <div className="mb-4">
          <h2 className="font-semibold text-foreground">Event Log</h2>
          <p className="text-sm text-muted-foreground">{events.length} recorded events</p>
        </div>

        <div className="space-y-3">
          {events.map((event, index) => (
            <button
              key={event.id}
              onClick={() => onSelectEvent(event.id)}
              className="w-full bg-card border border-border rounded-lg p-4 hover:border-primary transition-colors text-left group"
            >
              <div className="flex gap-3">
                <div className="flex-shrink-0">
                  {event.type === 'photo' ? (
                    <div className="w-16 h-16 bg-muted rounded flex items-center justify-center group-hover:bg-muted/50">
                      <Camera className="w-6 h-6 text-primary" />
                    </div>
                  ) : (
                    <div className="w-16 h-16 bg-muted rounded flex items-center justify-center group-hover:bg-muted/50">
                      <Play className="w-6 h-6 text-primary" />
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-sm text-primary">{event.timestamp}</span>
                    <StatusBadge variant={event.type === 'photo' ? 'evidence' : 'active'} size="sm">
                      {event.type === 'photo' ? 'PHOTO' : 'VIDEO'}
                    </StatusBadge>
                  </div>
                  
                  <p className="text-foreground font-medium mb-2">{event.description}</p>
                  
                  {event.metadata && (
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {Object.entries(event.metadata).map(([key, value]) => (
                        <div key={key} className="flex items-center gap-1 text-muted-foreground">
                          <Hash className="w-3 h-3" />
                          <span>{key}: {value}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
