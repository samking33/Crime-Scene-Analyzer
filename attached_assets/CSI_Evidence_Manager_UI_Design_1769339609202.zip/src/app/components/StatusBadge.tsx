import React from 'react';

type BadgeVariant = 'active' | 'closed' | 'evidence' | 'warning' | 'recording';

interface StatusBadgeProps {
  variant: BadgeVariant;
  children: React.ReactNode;
  size?: 'sm' | 'md';
}

const variantStyles: Record<BadgeVariant, string> = {
  active: 'bg-[#2FA4B9] text-white',
  closed: 'bg-[#374151] text-[#9CA3AF]',
  evidence: 'bg-[#D9A441] text-[#0F1A24]',
  warning: 'bg-[#D9A441] text-[#0F1A24]',
  recording: 'bg-[#C0392B] text-white'
};

export function StatusBadge({ variant, children, size = 'md' }: StatusBadgeProps) {
  const sizeClass = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm';
  
  return (
    <span className={`inline-flex items-center ${sizeClass} rounded font-semibold ${variantStyles[variant]}`}>
      {children}
    </span>
  );
}
