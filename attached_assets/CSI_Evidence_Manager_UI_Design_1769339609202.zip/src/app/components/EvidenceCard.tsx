import React from 'react';
import { Image, Video, Clock } from 'lucide-react';

export interface Evidence {
  id: string;
  type: 'photo' | 'video';
  timestamp: string;
  thumbnail?: string;
  caseId: string;
  evidenceId: string;
}

interface EvidenceCardProps {
  evidence: Evidence;
  onClick: () => void;
}

export function EvidenceCard({ evidence, onClick }: EvidenceCardProps) {
  return (
    <button
      onClick={onClick}
      className="w-full bg-card border border-border rounded-lg overflow-hidden hover:border-primary transition-colors group"
    >
      <div className="aspect-video bg-muted flex items-center justify-center relative">
        {evidence.type === 'photo' ? (
          <Image className="w-12 h-12 text-muted-foreground group-hover:text-primary transition-colors" />
        ) : (
          <Video className="w-12 h-12 text-muted-foreground group-hover:text-primary transition-colors" />
        )}
        <div className="absolute top-2 left-2 bg-black/70 px-2 py-1 rounded text-xs text-white font-mono">
          {evidence.type.toUpperCase()}
        </div>
      </div>
      
      <div className="p-3">
        <div className="text-sm font-mono text-foreground mb-1">
          {evidence.evidenceId}
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" />
          <span>{evidence.timestamp}</span>
        </div>
      </div>
    </button>
  );
}
