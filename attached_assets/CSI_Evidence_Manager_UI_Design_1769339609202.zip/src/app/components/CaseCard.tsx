import React from 'react';
import { FileText, Calendar } from 'lucide-react';
import { StatusBadge } from './StatusBadge';

export interface Case {
  id: string;
  title: string;
  caseNumber: string;
  date: string;
  status: 'active' | 'closed';
}

interface CaseCardProps {
  case: Case;
  onClick: () => void;
}

export function CaseCard({ case: caseData, onClick }: CaseCardProps) {
  return (
    <button
      onClick={onClick}
      className="w-full bg-card border border-border rounded-lg p-4 text-left hover:border-primary transition-colors"
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <span className="font-mono text-sm text-muted-foreground">{caseData.caseNumber}</span>
        </div>
        <StatusBadge variant={caseData.status} size="sm">
          {caseData.status.toUpperCase()}
        </StatusBadge>
      </div>
      
      <h3 className="font-semibold text-foreground mb-2">{caseData.title}</h3>
      
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Calendar className="w-4 h-4" />
        <span>{caseData.date}</span>
      </div>
    </button>
  );
}
