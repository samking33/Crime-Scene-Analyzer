import React from 'react';
import { ArrowLeft, FileText, Download, Share2, Package } from 'lucide-react';

interface ReportsScreenProps {
  caseNumber: string;
  caseTitle: string;
  evidenceCount: number;
  timelineEvents: number;
  onBack: () => void;
}

export function ReportsScreen({
  caseNumber,
  caseTitle,
  evidenceCount,
  timelineEvents,
  onBack
}: ReportsScreenProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <h1 className="font-semibold text-foreground">Reports & Export</h1>
              <p className="text-xs font-mono text-muted-foreground">{caseNumber}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Case Summary */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h2 className="font-semibold text-foreground mb-4">Case Summary</h2>
          
          <div className="space-y-3 text-sm">
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-muted-foreground">Case Title</span>
              <span className="text-foreground font-medium">{caseTitle}</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-muted-foreground">Case Number</span>
              <span className="text-foreground font-mono">{caseNumber}</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-muted-foreground">Evidence Items</span>
              <span className="text-foreground font-semibold">{evidenceCount}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-muted-foreground">Timeline Events</span>
              <span className="text-foreground font-semibold">{timelineEvents}</span>
            </div>
          </div>
        </div>

        {/* Export Options */}
        <div>
          <h2 className="font-semibold text-foreground mb-3">Export Options</h2>
          
          <div className="space-y-3">
            <button className="w-full bg-card border border-border rounded-lg p-4 hover:border-primary transition-colors text-left group">
              <div className="flex items-center gap-4">
                <div className="bg-primary/10 rounded-lg p-3 group-hover:bg-primary/20 transition-colors">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-foreground mb-1">PDF Report</div>
                  <div className="text-sm text-muted-foreground">
                    Complete case documentation with timeline and evidence
                  </div>
                </div>
                <Download className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
            </button>

            <button className="w-full bg-card border border-border rounded-lg p-4 hover:border-primary transition-colors text-left group">
              <div className="flex items-center gap-4">
                <div className="bg-primary/10 rounded-lg p-3 group-hover:bg-primary/20 transition-colors">
                  <Package className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-foreground mb-1">Evidence Package (ZIP)</div>
                  <div className="text-sm text-muted-foreground">
                    All evidence files with chain of custody metadata
                  </div>
                </div>
                <Download className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
            </button>

            <button className="w-full bg-card border border-border rounded-lg p-4 hover:border-primary transition-colors text-left group">
              <div className="flex items-center gap-4">
                <div className="bg-primary/10 rounded-lg p-3 group-hover:bg-primary/20 transition-colors">
                  <Share2 className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-foreground mb-1">Secure Share</div>
                  <div className="text-sm text-muted-foreground">
                    Generate encrypted share link for authorized personnel
                  </div>
                </div>
              </div>
            </button>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <p className="text-xs text-muted-foreground leading-relaxed">
            All exported materials are digitally signed and include cryptographic verification.
            Distribution is logged in the audit trail. Ensure proper authorization before sharing.
          </p>
        </div>
      </div>
    </div>
  );
}
