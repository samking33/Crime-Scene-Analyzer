import React, { useState } from 'react';
import { ArrowLeft, FileText } from 'lucide-react';

interface CreateInvestigationScreenProps {
  officerName: string;
  onBack: () => void;
  onStart: (data: {
    title: string;
    caseNumber: string;
    location: string;
  }) => void;
}

export function CreateInvestigationScreen({
  officerName,
  onBack,
  onStart
}: CreateInvestigationScreenProps) {
  const [title, setTitle] = useState('');
  const [caseNumber, setCaseNumber] = useState('');
  const [location, setLocation] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStart({ title, caseNumber, location });
  };

  const currentDateTime = new Date().toLocaleString('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short'
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="font-semibold text-foreground">Create Investigation</h1>
              <p className="text-xs text-muted-foreground">Initialize forensic session</p>
            </div>
          </div>
        </div>
      </div>

      {/* Form */}
      <div className="container max-w-2xl mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-card border border-border rounded-lg p-6 space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-semibold text-foreground mb-2">
                Case Title
              </label>
              <input
                id="title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-3 bg-background border border-input rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Incident or investigation description"
                required
              />
            </div>

            <div>
              <label htmlFor="caseNumber" className="block text-sm font-semibold text-foreground mb-2">
                Case Number
              </label>
              <input
                id="caseNumber"
                type="text"
                value={caseNumber}
                onChange={(e) => setCaseNumber(e.target.value)}
                className="w-full px-4 py-3 bg-background border border-input rounded-lg text-foreground font-mono placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="CS-2026-0125-001"
                required
              />
            </div>

            <div>
              <label htmlFor="location" className="block text-sm font-semibold text-foreground mb-2">
                Location
              </label>
              <input
                id="location"
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-4 py-3 bg-background border border-input rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Address or coordinates"
                required
              />
            </div>

            <div className="pt-4 border-t border-border space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Officer</span>
                <span className="text-foreground font-semibold">{officerName}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Date & Time</span>
                <span className="text-foreground font-mono">{currentDateTime}</span>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-primary text-primary-foreground px-6 py-4 rounded-lg font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
          >
            <FileText className="w-5 h-5" />
            Start Investigation
          </button>

          <p className="text-xs text-center text-muted-foreground">
            Starting investigation will initialize recording session
          </p>
        </form>
      </div>
    </div>
  );
}
