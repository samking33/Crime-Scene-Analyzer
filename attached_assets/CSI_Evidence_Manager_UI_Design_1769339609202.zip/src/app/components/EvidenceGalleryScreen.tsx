import React, { useState } from 'react';
import { ArrowLeft, Filter } from 'lucide-react';
import { EvidenceCard, Evidence } from './EvidenceCard';

interface EvidenceGalleryScreenProps {
  caseNumber: string;
  caseTitle: string;
  evidence: Evidence[];
  onBack: () => void;
  onSelectEvidence: (evidenceId: string) => void;
  onAnalyze: (evidenceId: string) => void;
}

export function EvidenceGalleryScreen({
  caseNumber,
  caseTitle,
  evidence,
  onBack,
  onSelectEvidence,
  onAnalyze
}: EvidenceGalleryScreenProps) {
  const [filter, setFilter] = useState<'all' | 'photo' | 'video'>('all');

  const filteredEvidence = evidence.filter((e) => {
    if (filter === 'all') return true;
    return e.type === filter;
  });

  const photoCount = evidence.filter((e) => e.type === 'photo').length;
  const videoCount = evidence.filter((e) => e.type === 'video').length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-3">
            <button
              onClick={onBack}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <h1 className="font-semibold text-foreground">Evidence Gallery</h1>
              <p className="text-xs font-mono text-muted-foreground">{caseNumber}</p>
            </div>
          </div>

          {/* Filter Controls */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded text-sm font-semibold transition-colors ${
                filter === 'all'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              All ({evidence.length})
            </button>
            <button
              onClick={() => setFilter('photo')}
              className={`px-3 py-1.5 rounded text-sm font-semibold transition-colors ${
                filter === 'photo'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              Photos ({photoCount})
            </button>
            <button
              onClick={() => setFilter('video')}
              className={`px-3 py-1.5 rounded text-sm font-semibold transition-colors ${
                filter === 'video'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              Videos ({videoCount})
            </button>
          </div>
        </div>
      </div>

      {/* Evidence Grid */}
      <div className="container max-w-2xl mx-auto px-4 py-6">
        <div className="grid grid-cols-2 gap-3">
          {filteredEvidence.map((item) => (
            <EvidenceCard
              key={item.id}
              evidence={item}
              onClick={() => onSelectEvidence(item.id)}
            />
          ))}
        </div>

        {filteredEvidence.length === 0 && (
          <div className="bg-card border border-border rounded-lg p-8 text-center">
            <p className="text-muted-foreground">No evidence found</p>
            <p className="text-sm text-muted-foreground mt-1">
              {filter !== 'all' ? `No ${filter}s captured yet` : 'Start recording to capture evidence'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
