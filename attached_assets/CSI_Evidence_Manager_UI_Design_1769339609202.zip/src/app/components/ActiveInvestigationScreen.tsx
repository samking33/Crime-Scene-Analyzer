import React, { useState, useEffect } from 'react';
import { ArrowLeft, Video, Camera, MapPin, Circle, Square, Clock } from 'lucide-react';
import { StatusBadge } from './StatusBadge';

interface ActiveInvestigationScreenProps {
  caseNumber: string;
  caseTitle: string;
  onBack: () => void;
  onViewTimeline: () => void;
  onViewEvidence: () => void;
}

export function ActiveInvestigationScreen({
  caseNumber,
  caseTitle,
  onBack,
  onViewTimeline,
  onViewEvidence
}: ActiveInvestigationScreenProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);

  useEffect(() => {
    if (isRecording) {
      const interval = setInterval(() => {
        setRecordingTime((t) => t + 1);
        setAudioLevel(Math.random() * 100);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isRecording]);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-2">
            <button
              onClick={onBack}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h1 className="font-semibold text-foreground">{caseTitle}</h1>
                {isRecording && (
                  <StatusBadge variant="recording" size="sm">
                    <Circle className="w-2 h-2 fill-current animate-pulse" />
                    <span className="ml-1">REC</span>
                  </StatusBadge>
                )}
              </div>
              <p className="text-xs font-mono text-muted-foreground">{caseNumber}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            <span>GPS: 37.7749° N, 122.4194° W</span>
          </div>
        </div>
      </div>

      {/* Camera Preview */}
      <div className="flex-1 bg-black relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <Video className="w-20 h-20 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500 text-sm">Live Camera Preview</p>
          </div>
        </div>

        {/* Recording Indicators Overlay */}
        {isRecording && (
          <>
            <div className="absolute top-4 left-4 bg-[#C0392B] px-3 py-2 rounded-lg flex items-center gap-2">
              <Circle className="w-3 h-3 fill-current animate-pulse" />
              <span className="text-white font-mono text-sm">{formatTime(recordingTime)}</span>
            </div>

            <div className="absolute top-4 right-4 bg-black/70 px-3 py-2 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="flex gap-0.5">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-1 h-4 rounded-sm ${
                        i * 12.5 < audioLevel ? 'bg-[#2FA4B9]' : 'bg-gray-600'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-white text-xs font-mono">AUDIO</span>
              </div>
            </div>

            <div className="absolute bottom-20 left-4 bg-black/70 px-3 py-2 rounded-lg text-white text-xs">
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Storage: 4.2 GB / 128 GB</span>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Controls */}
      <div className="bg-card border-t border-border">
        <div className="container max-w-2xl mx-auto px-4 py-6">
          <div className="flex items-center justify-center gap-4 mb-4">
            <button
              onClick={() => setIsRecording(!isRecording)}
              className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                isRecording
                  ? 'bg-[#C0392B] hover:bg-[#A82F24]'
                  : 'bg-primary hover:bg-primary/90'
              }`}
            >
              {isRecording ? (
                <Square className="w-8 h-8 text-white fill-current" />
              ) : (
                <Circle className="w-8 h-8 text-white fill-current" />
              )}
            </button>

            <button
              disabled={!isRecording}
              className="w-16 h-16 rounded-full bg-secondary hover:bg-secondary/80 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
            >
              <Camera className="w-6 h-6 text-secondary-foreground" />
            </button>
          </div>

          <div className="space-y-2">
            <button
              onClick={onViewTimeline}
              className="w-full bg-secondary text-secondary-foreground px-4 py-3 rounded-lg font-semibold hover:bg-secondary/80 transition-colors"
            >
              View Timeline
            </button>
            <button
              onClick={onViewEvidence}
              className="w-full bg-secondary text-secondary-foreground px-4 py-3 rounded-lg font-semibold hover:bg-secondary/80 transition-colors"
            >
              Evidence Gallery
            </button>
          </div>

          <p className="text-xs text-center text-muted-foreground mt-4">
            {isRecording ? 'Recording in progress' : 'Tap to start recording'}
          </p>
        </div>
      </div>
    </div>
  );
}
