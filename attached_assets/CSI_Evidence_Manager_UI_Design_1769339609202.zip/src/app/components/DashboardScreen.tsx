import React from 'react';
import { Plus, User, LogOut } from 'lucide-react';
import { CaseCard, Case } from './CaseCard';

interface DashboardScreenProps {
  officerName: string;
  badgeId: string;
  cases: Case[];
  onCreateCase: () => void;
  onSelectCase: (caseId: string) => void;
  onLogout: () => void;
}

export function DashboardScreen({
  officerName,
  badgeId,
  cases,
  onCreateCase,
  onSelectCase,
  onLogout
}: DashboardScreenProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-primary rounded-full p-2">
                <User className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <div className="font-semibold text-foreground">{officerName}</div>
                <div className="text-xs font-mono text-muted-foreground">ID: {badgeId}</div>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container max-w-2xl mx-auto px-4 py-6">
        <div className="mb-6">
          <button
            onClick={onCreateCase}
            className="w-full bg-primary text-primary-foreground px-6 py-4 rounded-lg font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Create New Investigation
          </button>
        </div>

        <div className="mb-4">
          <h2 className="font-semibold text-foreground">Active Investigations</h2>
          <p className="text-sm text-muted-foreground">{cases.length} total cases</p>
        </div>

        <div className="space-y-3">
          {cases.length === 0 ? (
            <div className="bg-card border border-border rounded-lg p-8 text-center">
              <p className="text-muted-foreground">No cases found</p>
              <p className="text-sm text-muted-foreground mt-1">
                Create your first investigation to get started
              </p>
            </div>
          ) : (
            cases.map((c) => (
              <CaseCard key={c.id} case={c} onClick={() => onSelectCase(c.id)} />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
