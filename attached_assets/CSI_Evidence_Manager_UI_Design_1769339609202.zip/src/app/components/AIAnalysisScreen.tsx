import React, { useState } from 'react';
import { ArrowLeft, Image as ImageIcon, Sparkles, CheckCircle, RefreshCw } from 'lucide-react';

interface AIAnalysisScreenProps {
  evidenceId: string;
  caseNumber: string;
  onBack: () => void;
  onApprove: (description: string) => void;
}

export function AIAnalysisScreen({
  evidenceId,
  caseNumber,
  onBack,
  onApprove
}: AIAnalysisScreenProps) {
  const [analysis, setAnalysis] = useState({
    objects: ['Vehicle - Dark Sedan', 'License Plate - Visible', 'Street Sign', 'Timestamp Marker'],
    scene: 'Exterior street scene, daytime lighting conditions. Primary subject is a dark-colored sedan parked adjacent to commercial building. Clear visibility, no obstruction.',
    suggested: 'Evidence photo #EV-2026-0125-003: Dark sedan, license plate visible, captured at intersection of Main St and 5th Ave. Timestamp: 14:23:47.'
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <h1 className="font-semibold text-foreground">AI Analysis</h1>
              <p className="text-xs font-mono text-muted-foreground">{evidenceId}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Image Preview */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="aspect-video bg-muted flex items-center justify-center">
            <ImageIcon className="w-20 h-20 text-muted-foreground" />
          </div>
          <div className="p-4">
            <p className="text-xs font-mono text-muted-foreground">
              {caseNumber} / {evidenceId}
            </p>
          </div>
        </div>

        {/* Analysis Results */}
        <div className="bg-card border border-border rounded-lg p-6 space-y-4">
          <div className="flex items-center gap-2 text-primary mb-4">
            <Sparkles className="w-5 h-5" />
            <h2 className="font-semibold">Automated Analysis</h2>
          </div>

          {/* Detected Objects */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">Detected Objects</h3>
            <div className="flex flex-wrap gap-2">
              {analysis.objects.map((obj, i) => (
                <span
                  key={i}
                  className="px-3 py-1 bg-secondary text-secondary-foreground rounded-full text-sm"
                >
                  {obj}
                </span>
              ))}
            </div>
          </div>

          {/* Scene Interpretation */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">Scene Interpretation</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {analysis.scene}
            </p>
          </div>

          {/* Suggested Description */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">Suggested Description</h3>
            <div className="bg-background border border-border rounded-lg p-4">
              <p className="text-sm text-foreground font-mono leading-relaxed">
                {analysis.suggested}
              </p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={() => {}}
            className="flex-1 bg-secondary text-secondary-foreground px-6 py-3 rounded-lg font-semibold hover:bg-secondary/80 transition-colors flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            Regenerate
          </button>
          <button
            onClick={() => onApprove(analysis.suggested)}
            className="flex-1 bg-primary text-primary-foreground px-6 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            Approve & Attach
          </button>
        </div>

        <p className="text-xs text-center text-muted-foreground">
          AI-generated descriptions must be reviewed and approved by authorized personnel
        </p>
      </div>
    </div>
  );
}
