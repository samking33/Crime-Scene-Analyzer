
  # CSI Evidence Manager UI Design

  This is a code bundle for CSI Evidence Manager UI Design. The original project is available at https://www.figma.com/design/mR3bKEzvLA2FLIsFcAOIow/CSI-Evidence-Manager-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  